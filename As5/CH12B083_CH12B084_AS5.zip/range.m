function f=range(theta)         %defining range function where angle(with horizontal) is variable 
f=-35.5*35.5*sin(2*theta)/9.8;  %Range=u*u*sin(2*theta)/g ; g=9.8 m/s^2
end