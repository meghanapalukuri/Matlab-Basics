function f=As5(A)                          %defining function with variable A
f=(A(1)^2+A(2)^2)^2-A(1)^2-A(2)+A(3)^2;    %A = [x y z]
                                           %f = (x^2+y^2)^2-x^2-y+z^2
end