clc;
clear all;
close all;
a=1;              %aX+bY+c=0
b=1;              %X+Y+1=0
L=sqrt((a^2)+(b^2));
X=2;
Y=3;

Ans=((a*X+b*Y+1)/L)     %minimum distance from a line X+Y+1=0

