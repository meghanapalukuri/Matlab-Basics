function v = fun(X)
x1=X(1);
x2=X(2);

v= (x1-4)^2+(x2-5)^2;

end
