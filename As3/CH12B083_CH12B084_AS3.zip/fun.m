function sol =fun(X,Re)
f= X;
sol=-0.4*sqrt(f)+sqrt(3*f)*log(Re*sqrt(f))-1;

end
